# Store the famous person's name in a variable
famous_person = "Albert Einstein"

# Store the quote in a variable
quote = "A person who never made a mistake never tried anything new."

# Compose the message
message = f'{famous_person} once said, "{quote}"'

# Print the message with the quote and the name of its author
print(message)
