# Store the names of your classmates in a list
names = ["Hameed", "Jalal", "Usman", "Taofeek"]

# Print a message for each person by accessing each element in the list
for name in names:
    message = f"Hello {name}, I hope you're having a great day!"
    print(message)
