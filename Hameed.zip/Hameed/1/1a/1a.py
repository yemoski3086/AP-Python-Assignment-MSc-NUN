# Store your name in a variable
your_name = "Hameed"

# Print a message about the Python class
print(f"Hello {your_name}, I am taking some Python classes!")

# Print your name in lowercase, uppercase, and titlecase
print(f"Lowercase: {your_name.lower()}")
print(f"Uppercase: {your_name.upper()}")
print(f"Titlecase: {your_name.title()}")

# Repeat the sentences
print(f"Repeat 1: Hello {your_name}, I am taking some Python classes!")
print(f"Repeat 2: Hello {your_name}, I am taking some Python classes!")
print(f"Repeat 3: Hello {your_name}, I am taking some Python classes!")