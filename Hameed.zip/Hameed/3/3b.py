# Function to show magicians
def show_magicians(magicians):
    for magician in magicians:
        print(magician)

# Function to modify the list of magicians
def make_great(magicians):
    great_magicians = [f"{magician} the Great" for magician in magicians]
    return great_magicians

# List of magician's names
magicians = ["Merlin", "Houdini", "David Copperfield"]

# Show original magicians
print("Original magicians:")
show_magicians(magicians)

# Modify the list and show the modified magicians
magicians = make_great(magicians)
print("\nMagicians after adding 'the Great':")
show_magicians(magicians)

# Make a copy of the list and modify it separately
new_magicians = make_great(magicians.copy())
print("\nOriginal magicians (unchanged):")
show_magicians(magicians)

print("\nNew magicians (separate list with 'the Great' added):")
show_magicians(new_magicians)
