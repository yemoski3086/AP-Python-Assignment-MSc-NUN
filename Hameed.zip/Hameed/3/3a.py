def make_album(artist, title, tracks=None):
    album = {"artist": artist, "title": title}
    if tracks:
        album["tracks"] = tracks
    return album

# Make three dictionaries representing different albums
album1 = make_album("Artist1", "Album1", 10)
album2 = make_album("Artist2", "Album2")
album3 = make_album("Artist3", "Album3", 15)

# Print each return value
print(album1)
print(album2)
print(album3)

while True:
    artist = input("Enter the artist's name (or 'quit' to exit): ")
    if artist.lower() == 'quit':
        break
    title = input("Enter the album title: ")
    
    album_info = make_album(artist, title)
    print(album_info)
