# Step 1
invitees = ["Albert Einstein", "Maya Angelou", "Elon Musk"]

# Print invitation messages
for person in invitees:
    invitation_message = f"Dear {person},\nYou are cordially invited to my graduation ceremony. Your presence would mean a lot to me on this special occasion.\nSincerely, Hameed"
    print(invitation_message)

# Step 2
guest_cant_make_it = "Elon Musk"
print(f"\nUnfortunately, {guest_cant_make_it} can't make it to the graduation.")

# Step 3
new_guest = "Nelson Mandela"
invitees[invitees.index(guest_cant_make_it)] = new_guest

# Step 4
for person in invitees:
    invitation_message = f"Dear {person},\nYou are cordially invited to my graduation ceremony. Your presence would mean a lot to me on this special occasion.\nSincerely, Hameed"
    print(invitation_message)

# Step 5
more_guests = ["Ada Lovelace", "Marie Curie", "Nikola Tesla"]
print("\nGood news! We can now accommodate more guests at the graduation.")

# Step 6
invitees.insert(0, "Isaac Newton")

# Step 7
invitees.insert(len(invitees)//2, "Galileo Galilei")

# Step 8
invitees.append("Stephen Hawking")

# Step 9
for person in invitees:
    invitation_message = f"Dear {person},\nYou are cordially invited to my graduation ceremony. Your presence would mean a lot to me on this special occasion.\nSincerely, Hameed"
    print(invitation_message)

# Step 10
print("\nDue to organizational issues, I can only invite two people to the graduation.")

# Step 11
while len(invitees) > 2:
    removed_person = invitees.pop()
    print(f"Sorry, {removed_person}, I can't invite you to the graduation.")

# Step 12
for person in invitees:
    print(f"{person}, you are still invited to the graduation.")

# Step 13
invitees.sort()
print("\nSorted guest list:", invitees)

# Step 14
invitees.reverse()
print("Reversed guest list:", invitees)

# Step 15
del invitees[-2:]
print("\nFinal guest list:", invitees)
