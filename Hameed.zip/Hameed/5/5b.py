# Version where the alien's color is green
alien_color_green = 'green'

if alien_color_green == 'green':
    print("Congratulations! You just earned 5 points for shooting the green alien.")
else:
    print("Congratulations! You just earned 10 points.")

# Version where the alien's color is not green
alien_color_not_green = 'yellow'

if alien_color_not_green == 'green':
    print("Congratulations! You just earned 5 points for shooting the green alien.")
else:
    print("Congratulations! You just earned 10 points.")
