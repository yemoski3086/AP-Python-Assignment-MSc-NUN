# Alien color that passes the if test
alien_color_pass = 'green'

if alien_color_pass == 'green':
    print("Congratulations! You just earned 5 points.")

# Alien color that fails the if test
alien_color_fail = 'red'

if alien_color_fail == 'green':
    print("Congratulations! You just earned 5 points.")
# No output because the condition is not met
