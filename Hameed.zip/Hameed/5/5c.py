# Alien color is green
alien_color_green = 'green'

if alien_color_green == 'green':
    print("Congratulations! You just earned 5 points.")
elif alien_color_green == 'yellow':
    print("Congratulations! You just earned 10 points.")
else:
    print("Congratulations! You just earned 15 points.")

# Alien color is yellow
alien_color_yellow = 'yellow'

if alien_color_yellow == 'green':
    print("Congratulations! You just earned 5 points.")
elif alien_color_yellow == 'yellow':
    print("Congratulations! You just earned 10 points.")
else:
    print("Congratulations! You just earned 15 points.")

# Alien color is red
alien_color_red = 'red'

if alien_color_red == 'green':
    print("Congratulations! You just earned 5 points.")
elif alien_color_red == 'yellow':
    print("Congratulations! You just earned 10 points.")
else:
    print("Congratulations! You just earned 15 points.")

