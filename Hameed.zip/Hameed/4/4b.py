# Version 1: Conditional test in the while statement to stop the loop
while True:
    age = int(input("Enter your age (enter 0 to quit): "))
    if age == 0:
        break
    elif age < 3:
        print("Your ticket is free.")
    elif 3 <= age <= 12:
        print("Your ticket costs N5,000.")
    else:
        print("Your ticket costs N10,000.")

# Version 2: Active variable to control the loop
active = True
while active:
    age = int(input("Enter your age (enter 0 to quit): "))
    if age == 0:
        active = False
    elif age < 3:
        print("Your ticket is free.")
    elif 3 <= age <= 12:
        print("Your ticket costs N5,000.")
    else:
        print("Your ticket costs N10,000.")

# Version 3: Break statement to exit the loop with a 'quit' value
while True:
    age_input = input("Enter your age (enter 'quit' to exit): ")
    if age_input.lower() == 'quit':
        break
    age = int(age_input)
    if age < 3:
        print("Your ticket is free.")
    elif 3 <= age <= 12:
        print("Your ticket costs N5,000.")
    else:
        print("Your ticket costs N10,000.")
