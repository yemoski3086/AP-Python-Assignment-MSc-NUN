# Using a for loop
cubes_for_loop = []
for num in range(1, 11):
    cubes_for_loop.append(num ** 3)

# Using list comprehension
cubes_list_comp = [num ** 3 for num in range(1, 11)]

# Print the values
print("Using a for loop:", cubes_for_loop)
print("Using list comprehension:", cubes_list_comp)
